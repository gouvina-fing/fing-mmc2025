# Métodos de Monte Carlo (2025)
Tareas del curso de Métodos de Monte Carlo 2025, Facultad de Ingeniería (UdelaR).

## Requisitos

1. Instalar *Python 3.12*

2. Crear ambiente virtual <br>
`python -m venv env`

3. Instalar requerimientos <br>
`pip install -r requirements.txt`

4. Ejecutar script elegido <br>
`python lab.py <parámetros>`